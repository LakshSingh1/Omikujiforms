package co.lakshsingh.omikujiforms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmikujiformsApplicationTests {

	@Test
	void contextLoads() {
	}

}
