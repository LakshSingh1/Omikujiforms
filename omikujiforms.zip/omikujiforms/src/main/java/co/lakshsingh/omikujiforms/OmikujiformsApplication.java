package co.lakshsingh.omikujiforms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmikujiformsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmikujiformsApplication.class, args);
	}

}
