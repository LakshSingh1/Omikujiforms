package co.lakshsingh.omikujiforms.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class FormsController {
    

    @GetMapping("/omikuji")
    public String index(){
        return "index.jsp";
    }

    @PostMapping("/handleForm")
    public String handleForm(Integer number, String city, String person, String hobby, String thing ,HttpSession session){
        System.out.println(city);
        System.out.println(person);
        System.out.println(hobby);
        System.out.println(thing);


        session.setAttribute("number", number);
        session.setAttribute("city", city);
        session.setAttribute("person", person);
        session.setAttribute("hobby", hobby);
        session.setAttribute("thing", thing);
        return "redirect:/show";
    }

    @GetMapping("/show")
    public String show(){
        return "show.jsp";
    }
}

